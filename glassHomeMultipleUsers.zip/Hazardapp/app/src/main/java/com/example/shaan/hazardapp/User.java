package com.example.shaan.hazardapp;

public class User {
    private String frontDoor;
    private String garageDoor;
    private String airQ;




    public User(String frontDoor, String garageDoor, String airQ) {
        this.frontDoor = frontDoor;
        this.garageDoor = garageDoor;
        this.airQ = airQ;
    }

    public String getFrontDoor() {
        return frontDoor;
    }

    public void setFrontDoor(String frontDoor) {
        this.frontDoor = frontDoor;
    }

    public String getGarageDoor() {
        return garageDoor;
    }

    public void setGarageDoor(String garageDoor) {
        this.garageDoor = garageDoor;
    }

    public String getAirQ() {
        return airQ;
    }

    public void setAirQ(String airQ) {
        this.airQ = airQ;
    }
}
